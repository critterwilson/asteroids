#ifndef ship_h
#define ship_h

#include <stdio.h>
#include "flyingObject.h"
#include "uiDraw.h"



#endif /* ship_h */

class Ship : public FlyingObject
{
public:
    Ship();
    void draw();
    int getRotation() const {return rotation; }
    int getShields() const {return shields; }
    bool getBoolShields() const {return boolShields; }
    bool getThrust() const {return thrust; }
    void hit();
    
    
    void setRotation(int rotation) {this->rotation = rotation; }
    void setShields(int shieldPower) {this->shields = shieldPower; }
    void setThrust(bool thrust) {this->thrust = thrust; }
        
    void shieldsAlive(bool alive)
    {
        this->boolShields = alive;
    }
    
    void rotateRight();
    void rotateLeft();
    void moveForward();
private:
    int rotation;
    int shields;
    bool boolShields;
    bool thrust;
    
    
};
