//
//  Astroid.cpp
//  Astroids
//
//  Created by Christopher Wilson on 6/29/18.
//  Copyright © 2018 Christopher Wilson. All rights reserved.
//

#include "astroid.h"

/**********************************************************
 * Constructor: Astroid
 * Description: Yep
 **********************************************************/
Astroid :: Astroid()
{
}


